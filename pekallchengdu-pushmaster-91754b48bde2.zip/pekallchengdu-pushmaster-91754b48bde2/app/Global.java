import org.joda.time.DateTime;
import org.vertx.java.core.Handler;
import org.vertx.java.core.eventbus.EventBus;
import org.vertx.java.core.eventbus.Message;
import org.vertx.java.core.json.JsonObject;
import play.Application;
import play.GlobalSettings;
import play.Logger;
import playHazelcast.api.PlayHz;
import playvertx.VertX;
import scala.concurrent.duration.Duration;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Author: kerr
 * Mail: pin.he@pekall.com
 */
public class Global extends GlobalSettings {
    @Override
    public void onStart(Application application) {
        super.onStart(application);

		final EventBus bus = getEventBus();
        Logger.info("TESTVERTX : Got EVENT BUS");

        // / Listening on EventBUS
        bus.registerHandler("someaddress", new Handler<Message<JsonObject>>() {
            public void handle(Message<JsonObject> msg) {
                Logger.info("Listening on master : " + msg.body());
            }
        });

        // / Publishing on EventBus
        play.libs.Akka
                .system()
                .scheduler()
                .schedule(Duration.create(100, TimeUnit.MILLISECONDS),
                        Duration.create(100, TimeUnit.MILLISECONDS), new Runnable() {
                    @Override
                    public void run() {
                        Map<String, Object> jsonMap = new HashMap<String, Object>();
                        jsonMap.put("text", "Hello, slaver!"
                                + DateTime.now());
                        bus.publish("someaddress", new JsonObject(
                                jsonMap));

                    }
                }, play.libs.Akka.system().dispatcher());
    }

    @Override
    public void onStop(Application application) {
        super.onStop(application);
    }

    public EventBus getEventBus() {
        return VertX.vertx().get().eventBus();
    }

    public int clusterSize(){
        return PlayHz.getInstance().get().getCluster().getMembers().size();
    }
}
